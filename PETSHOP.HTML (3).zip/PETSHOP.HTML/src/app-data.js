const STORAGE_KEY = 'petshop-feliz-v2';

const seed = {
    users: [],
    currentUserId: null,
    categories: [
        { id: 'cat-dogs', name: 'Cachorros', description: 'Coleiras, brinquedos e alimentação para cães.' },
        { id: 'cat-cats', name: 'Gatos', description: 'Arranhadores, areia higiênica e petiscos.' },
        { id: 'cat-rabbits', name: 'Coelhos', description: 'Feno, casinhas e acessórios para roedores.' },
        { id: 'cat-birds', name: 'Pássaros', description: 'Gaiolas, comedouros e brinquedos coloridos.' }
    ],
    products: [
        { id: 'seed-coleira-ajustavel', categoryId: 'cat-dogs', name: 'Coleira ajustável', price: 39.99, description: 'Coleira confortável com material macio e resistente.', image: 'images/coleira-ajustavel.jpg' },
        { id: 'seed-caminha-acolchoada', categoryId: 'cat-dogs', name: 'Caminha acolchoada', price: 129.90, description: 'Cama macia para descanso seguro e elegante.', image: 'images/caminha-acolchoada.jpg' },
        { id: 'seed-racao-premium', categoryId: 'cat-dogs', name: 'Ração premium', price: 89.90, description: 'Alimento balanceado para todas as idades.', image: 'images/racao-premium.jpg' },
        { id: 'seed-brinquedo-de-mordida', categoryId: 'cat-dogs', name: 'Brinquedo de mordida', price: 24.99, description: 'Brinquedo durável para mastigar e brincar.', image: 'images/brinquedo-de-mordida.jpg' },
        { id: 'seed-kit-de-higiene', categoryId: 'cat-dogs', name: 'Kit de higiene', price: 49.90, description: 'Shampoo, condicionador e perfume para pelagem saudável.', image: 'images/kit-de-higiene.jpg' },
        { id: 'seed-arranhador-vertical', categoryId: 'cat-cats', name: 'Arranhador vertical', price: 79.90, description: 'Arranhador com base estável e pelúcia.', image: 'images/arranhador-vertical.jpg' },
        { id: 'seed-areia-higienica', categoryId: 'cat-cats', name: 'Areia higiênica', price: 34.90, description: 'Areia absorvente com controle de odores.', image: 'images/areia-higienica.jpg' },
        { id: 'seed-brinquedo-com-pena', categoryId: 'cat-cats', name: 'Brinquedo com pena', price: 19.90, description: 'Pega-pega para estimular o instinto de caça.', image: 'images/brinquedo-com-pena.jpg' },
        { id: 'seed-racao-sabor-peixe', categoryId: 'cat-cats', name: 'Ração sabor peixe', price: 74.90, description: 'Ração saborosa para paladares exigentes.', image: 'images/racao-sabor-peixe.jpg' },
        { id: 'seed-coleira-com-guizo', categoryId: 'cat-cats', name: 'Coleira com guizo', price: 29.90, description: 'Coleira leve com sininho para gatos curiosos.', image: 'images/coleira-com-guizo.jpg' },
        { id: 'seed-feno-natural', categoryId: 'cat-rabbits', name: 'Feno natural', price: 42.90, description: 'Feno fresco para uma dieta saudável e rica em fibras.', image: 'images/feno-natural.jpg' },
        { id: 'seed-tapete-de-palha', categoryId: 'cat-rabbits', name: 'Tapete de palha', price: 34.90, description: 'Tapete confortável para descansar e roer.', image: 'images/tapete-de-palha.jpg' },
        { id: 'seed-casa-de-madeira', categoryId: 'cat-rabbits', name: 'Casa de madeira', price: 99.90, description: 'Abrigo seguro e aconchegante para roedores.', image: 'images/casa-de-madeira.jpg' },
        { id: 'seed-mix-de-sementes', categoryId: 'cat-rabbits', name: 'Mix de sementes', price: 27.90, description: 'Mistura nutritiva para coelhos e pequenos animais.', image: 'images/mix-de-sementes.jpg' },
        { id: 'seed-bebedouro-de-bico', categoryId: 'cat-rabbits', name: 'Bebedouro de bico', price: 39.90, description: 'Bebedouro prático para manter água fresca.', image: 'images/bebedouro-de-bico.jpg' },
        { id: 'seed-gaiola-espacosa', categoryId: 'cat-birds', name: 'Gaiola espaçosa', price: 149.90, description: 'Gaiola resistente com poleiros confortáveis.', image: 'images/gaiola-espacosa.jpg' },
        { id: 'seed-comedouro-duplo', categoryId: 'cat-birds', name: 'Comedouro duplo', price: 34.90, description: 'Comedouro e bebedouro fácil de limpar.', image: 'images/comedouro-duplo.jpg' },
        { id: 'seed-balanco-para-passaro', categoryId: 'cat-birds', name: 'Balanço para pássaro', price: 24.90, description: 'Brinquedo para voar e se exercitar.', image: 'images/balanco-para-passaro.jpg' },
        { id: 'seed-racao-para-aves', categoryId: 'cat-birds', name: 'Ração para aves', price: 29.90, description: 'Alimento rico em nutrientes para aves pequenas.', image: 'images/racao-para-aves.jpg' },
        { id: 'seed-banho-para-passaros', categoryId: 'cat-birds', name: 'Banho para pássaros', price: 18.90, description: 'Banheira segura para higiene e diversão.', image: 'images/banho-para-passaros.jpg' }
    ],
    orders: [],
    cart: []
};

function clone(value) {
    return JSON.parse(JSON.stringify(value));
}

function loadState() {
    const saved = localStorage.getItem(STORAGE_KEY);
    const loaded = saved ? JSON.parse(saved) : clone(seed);
    const state = { ...clone(seed), ...loaded, cart: loaded.cart || [] };
    seed.categories.forEach(category => {
        if (!state.categories.some(item => item.id === category.id)) state.categories.push({ ...category });
    });
    seed.products.forEach(product => {
        if (!state.products.some(item => item.name.trim().toLowerCase() === product.name.trim().toLowerCase())) {
            state.products.push({ ...product });
        }
    });
    saveState(state);
    return state;
}

function saveState(state) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
}

function money(value) {
    return Number(value || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}

function orderTotal(order) {
    return (order.items || []).reduce((sum, item) => sum + item.price * item.quantity, 0);
}

function categoryName(state, id) {
    return state.categories.find(category => category.id === id)?.name || 'Sem categoria';
}

async function hashPassword(password, salt) {
    const data = new TextEncoder().encode(`${salt}:${password}`);
    const hash = await crypto.subtle.digest('SHA-256', data);
    return Array.from(new Uint8Array(hash)).map(byte => byte.toString(16).padStart(2, '0')).join('');
}
